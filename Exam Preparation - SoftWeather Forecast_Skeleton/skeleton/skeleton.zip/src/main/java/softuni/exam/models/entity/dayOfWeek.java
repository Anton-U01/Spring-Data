package softuni.exam.models.entity;

public enum dayOfWeek {
    FRIDAY, SATURDAY, SUNDAY
}
